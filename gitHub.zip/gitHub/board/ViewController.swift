//
//  ViewController.swift
//  board
//
//  Created by John Zalubski on 10/21/18.
//  Copyright © 2018 John Zalubski. All rights reserved.
//

import UIKit
import SceneKit
import ARKit

class ViewController: UIViewController, ARSCNViewDelegate {

    @IBOutlet var sceneView: ARSCNView!
    
   
    override func viewDidLoad() {
        super.viewDidLoad()
        sceneView.delegate = self
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        let configuration = ARWorldTrackingConfiguration()
        sceneView.session.run(configuration)
    }


    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard
            let touchPosition = touches.first?.location(in: sceneView),
            let hitTest = sceneView.hitTest(touchPosition, types: .featurePoint).first
            else {return}

        let node = SCNScene(named: "art.scnassets/dontCare.scn")!.rootNode.childNodes.first!
        node.simdTransform = hitTest.worldTransform
        sceneView.scene.rootNode.addChildNode(node)
    }

  
    
}
